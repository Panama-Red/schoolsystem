<?php
if(isset($_POST['AddRecord']))
{
$StudentID = $_POST["StudentID"];
$StudentName = $_POST["StudentName"];
$DOB = $_POST["DOB"];
$Gender = filter_input(INPUT_POST "Gender", FILTER_VALIDATE_INT);
$CountryOfBirth = $_POST["CountryOfBirth"];
$StateOfBirth = $_POST["StateOfBirth"];
$CityOfBirth = $_POST["CityOfBirth"];
$Address = $_POST["Address"];
$City = $_POST["City"];
$State = $_POST["State"];
$Zip = $_POST["Zip"];
$Status = filter_input(INPUT_POST, "Status", FILTER_VALIDATE_INT);
$UpdatedOn = $_POST["UpdatedOn"];
$UpdatedBy = $_POST["UpdatedBy"];
}

$host = "localhost";
$username = "root";
$password = "";
$dbname = "schoolsystem"

$conn = mysqli_connect(hostname: $host,
                username: $username,
                password: $password, 
                database: $dbname);

if (!$conn) {
    die("Connection error: " . mysqli_connect_error());
}

echo "Connection successful.";

$sql = "INSERT INTO students (StudentID, StudentName, DOB, Gender, CountryOfBirth, StateOfBirth,
    CityOfBirth, Address, State, City, ZipCode, Status, UpdatedOn, UpdatedBy)
    VALUES('0', '$StudentName', '$DOB', '$Gender', '$CountryOfBirth', '$StateOfBirth', '$CityOfBirth', '$Address',
    '$State', '$City', '0', '$Status', '$UpdatedOn', '$UpdatedBy' )";

qli_query($conn, $sql);

Record Saved.

ose($conn);
?>