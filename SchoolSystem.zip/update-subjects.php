//subjects

<?php
include('process-subjects-form.php');

if(isset($_GET['Edit']))
{
$id = $_GET['Edit'];
$query = "SELECT SubjectID, SubjectName, ClassName, Duration, Status, UpdatedOn
FROM subjects
WHERE id= $id;
$result = mysqli_query($conn, $query);
$editData = mysqli_fetch_assoc($result);

$SubjectID = $editData['SubjectID'];
$SubjectName = $editData['SubjectName'];
$ClassName = $editData['ClassName'];
$Duration = $editData['Duration'];
$Status = $editData['Status'];
$UpdatedOn = $editData['UpdatedOn'];
}

?>