//classes

<?php
include('process-classes-form.php');

if(isset($_GET['Edit']))
{
$id = $_GET['Edit'];
$query = "SELECT ClassID, ClassName, Subject, Section, EmpName, Status, UpdatedOn
FROM classes
WHERE id= $id;
$result = mysqli_query($conn, $query);
$editData = mysqli_fetch_assoc($result);

$ClassID = $editData['ClassID'];
$ClassName = $editData['ClassName'];
$Subject = $editData['Subject'];
$Section = $editData['Section'];
$EmpName = $editData['EmpName'];
$Status = $editData['Status'];
$UpdatedOn = $editData['UpdatedOn'];
}

?>