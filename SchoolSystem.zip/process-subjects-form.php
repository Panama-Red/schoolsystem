<?php
if(isset($_POST['AddRecord']))
{
$SubjectID = $_POST["SubjectID"];
$SubjectName = $_POST["SubjectName"];
$ClassName = $_POST["ClassName"];
$Duration = $_POST["Duration"];
$Status = filter_input(INPUT_POST, "Status", FILTER_VALIDATE_INT);
$UpdatedOn = $_POST["UpdatedOn"];
}

$host = "localhost";
$username = "root";
$password = "";
$dbname = "schoolsystem"

$conn = mysqli_connect(hostname: $host,
                username: $username,
                password: $password, 
                database: $dbname);

if (!$conn) {
    die("Connection error: " . mysqli_connect_error());
}

echo "Connection successful.";

$sql = "INSERT INTO subjects (SubjectID, SubjectName, ClassName, Duration, Status, UpdatedOn)
    VALUES('0', '$SubjectName', '$ClassName', '$Duration', '$Status', '$UpdatedOn')";

qli_query($conn, $sql);

Record Saved.

ose($conn);
?>