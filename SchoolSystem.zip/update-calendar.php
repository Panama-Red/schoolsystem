//calendar

<?php
include('process-calendar-form.php');

if(isset($_GET['Edit']))
{
$id = $_GET['Edit'];
$query = "SELECT AcademicYear, AcademicMonth, MonthName
FROM calendar
WHERE id= $id;
$result = mysqli_query($conn, $query);
$editData = mysqli_fetch_assoc($result);

$AcademicYear = $editData['AcademicYear'];
$AcademicMonth = $editData['AcademicMonth'];
$MonthName = $editData['MonthName'];
}

?>