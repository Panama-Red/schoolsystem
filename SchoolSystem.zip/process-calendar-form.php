<?php
if(isset($_POST['AddRecord']))
{
$AcademicYear = $_POST["AcademicYear"];
$AcademicMonth = $_POST["AcademicMonth"];
$MonthName = $_POST["MonthName"];
}

$host = "localhost";
$username = "root";
$password = "";
$dbname = "schoolsystem"

$conn = mysqli_connect(hostname: $host,
                username: $username,
                password: $password, 
                database: $dbname);

if (!$conn) {
    die("Connection error: " . mysqli_connect_error());
}

echo "Connection successful.";

$sql = "INSERT INTO calendar (AcademicYear, AcademicMonth, MonthName)
    VALUES('0', '$AcademicMonth, $MonthName)";

qli_query($conn, $sql);

Record Saved.

ose($conn);
?>