<?php
if(isset($_POST['AddRecord']))
{
$ClassID = $_POST["ClassID"];
$ClassName = $_POST["ClassName"];
$Subject = $_POST["Subject"];
$Section = $_POST["Section"];
$EmpName = $_POST["EmpName"];
$Status = filter_input(INPUT_POST, "Status", FILTER_VALIDATE_INT);
$UpdatedOn = $_POST["UpdatedOn"];
}

$host = "localhost";
$username = "root";
$password = "";
$dbname = "schoolsystem"

$conn = mysqli_connect(hostname: $host,
                username: $username,
                password: $password, 
                database: $dbname);

if (!$conn) {
    die("Connection error: " . mysqli_connect_error());
}

echo "Connection successful.";

$sql = "INSERT INTO classes (ClassID, ClassName, Subject, Section, EmpName, Status, UpdatedOn)
    VALUES('0', '$ClassName', '$Subject', '$Section', '$EmpName', '$Status', '$UpdatedOn')";

qli_query($conn, $sql);

Record Saved.

ose($conn);
?>