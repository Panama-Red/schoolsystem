//students

<?php
include('process-studentID-form.php');

if(isset($_GET['Edit']))
{
$id = $_GET['Edit'];
$query = "SELECT StudentID, StudentName, DOB, Gender, CountryOfBirth, StateOfBirth, CityOfBirth, Address,
City, State, ZipCode, Status, UpdatedOn, UpdatedBy
FROM students
WHERE id= $id;
$result = mysqli_query($conn, $query);
$editData = mysqli_fetch_assoc($result);

$EmpID = $editData['StudentID'];
$EmpName = $editData['StudentName'];
$DOB = $editData['DOB'];
$Gender = $editData['Gender'];
$CountryOfBirth = $editData['CountryOfBirth'];
$StateOfBirth = $editData['StateOfBirth'];
$CityOfBirth = $editData['CityOfBith'];
$Address = $editData['Address'];
$City = $editData['City'];
$State = $editData['State'];
$ZipCode = $editData['ZipCode'];
$Status = $editData['Status'];
$UpdatedOn = $editData['UpdatedOn'];
$UpdatedBy = $editData['UpdatedBy'];
}

?>