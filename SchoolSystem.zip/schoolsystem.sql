-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 17, 2023 at 08:25 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `schoolsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `calendar`
--

CREATE TABLE `calendar` (
  `AcademicYear` year(4) NOT NULL,
  `AcademicMonth` int(11) NOT NULL,
  `MonthName` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `ClassID` varchar(65) NOT NULL,
  `ClassName` varchar(65) NOT NULL,
  `Subject` varchar(65) NOT NULL,
  `Section` int(11) NOT NULL,
  `Teacher` varchar(65) NOT NULL,
  `Duration` int(11) NOT NULL,
  `Status` set('Active','Inactive','','') NOT NULL,
  `UpdatedOn` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `EmpID` varchar(65) NOT NULL COMMENT 'Employee ID',
  `EmpName` varchar(65) NOT NULL COMMENT 'Employee Name',
  `DOB` date NOT NULL COMMENT 'DOB',
  `Gender` set('Male','Female','','') NOT NULL COMMENT 'Gender',
  `CountryOfBirth` varchar(65) NOT NULL COMMENT 'Country Of Birth',
  `StateOfBirth` varchar(65) NOT NULL COMMENT 'State Of Birth',
  `CityOfBirth` varchar(65) NOT NULL COMMENT 'City Of Birth',
  `Address` varchar(75) NOT NULL COMMENT 'Address',
  `City` varchar(65) NOT NULL COMMENT 'City',
  `State` varchar(25) NOT NULL COMMENT 'State',
  `ZipCode` int(11) NOT NULL COMMENT 'Zip Code',
  `Status` set('Full Time','Part Time','Suspended','Terminated','On Leave') NOT NULL COMMENT 'Status',
  `UpdatedOn` date NOT NULL DEFAULT current_timestamp() COMMENT 'Updated On',
  `UpdatedBy` int(11) NOT NULL COMMENT 'Updated By'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `ExamID` varchar(65) NOT NULL,
  `ClassName` varchar(65) NOT NULL,
  `SubjectName` varchar(65) NOT NULL,
  `EmpName` varchar(65) NOT NULL,
  `StudentID` varchar(65) NOT NULL,
  `StudentName` varchar(65) NOT NULL,
  `DateOfExam` date NOT NULL,
  `Duration` int(11) NOT NULL,
  `Grade` int(11) NOT NULL,
  `UpdatedOn` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `StudentID` varchar(65) NOT NULL COMMENT 'Student ID',
  `StudentName` varchar(65) NOT NULL COMMENT 'Student Name',
  `DOB` date NOT NULL COMMENT 'DOB',
  `Gender` set('Male','Female','','') NOT NULL COMMENT 'Gender',
  `CountryOfBirth` varchar(65) NOT NULL COMMENT 'Country of Birth',
  `StateOfBirth` varchar(65) NOT NULL COMMENT 'State of Birth',
  `CityOfBirth` varchar(65) NOT NULL COMMENT 'City of Birth',
  `Address` varchar(75) NOT NULL COMMENT 'Address',
  `City` varchar(65) NOT NULL COMMENT 'City',
  `State` varchar(50) NOT NULL COMMENT 'State',
  `ZipCode` int(11) NOT NULL COMMENT 'Zip Code',
  `Status` set('Enrolled','Unenrolled','Suspended','Expelled') NOT NULL COMMENT 'Status',
  `UpdatedOn` date NOT NULL DEFAULT current_timestamp() COMMENT 'Updated On',
  `UpdatedBy` int(11) NOT NULL COMMENT 'Employee ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `SubjectID` varchar(65) NOT NULL,
  `SubjectName` varchar(65) NOT NULL,
  `ClassName` varchar(65) NOT NULL,
  `Duration` int(11) NOT NULL,
  `Status` set('Active','Inactive','','') NOT NULL,
  `UpdatedOn` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `calendar`
--
ALTER TABLE `calendar`
  ADD PRIMARY KEY (`AcademicYear`),
  ADD KEY `AcademicYear` (`AcademicYear`),
  ADD KEY `AcademicMonth` (`AcademicMonth`,`MonthName`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`ClassID`),
  ADD KEY `ClassID` (`ClassID`),
  ADD KEY `ClassName` (`ClassName`,`Subject`,`Section`,`Teacher`,`Duration`,`Status`,`UpdatedOn`),
  ADD KEY `Subject` (`Subject`),
  ADD KEY `Teacher` (`Teacher`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`EmpID`),
  ADD KEY `EmpID` (`EmpID`),
  ADD KEY `EmpName` (`EmpName`,`DOB`,`Gender`,`CountryOfBirth`,`StateOfBirth`,`CityOfBirth`,`Address`,`City`,`State`,`ZipCode`,`Status`,`UpdatedOn`,`UpdatedBy`);

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`ExamID`),
  ADD KEY `ExamID` (`ExamID`),
  ADD KEY `ClassName` (`ClassName`,`SubjectName`,`EmpName`,`StudentID`,`StudentName`,`DateOfExam`,`Duration`,`Grade`,`UpdatedOn`),
  ADD KEY `StudentID` (`StudentID`),
  ADD KEY `SubjectName` (`SubjectName`),
  ADD KEY `EmpName` (`EmpName`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`StudentID`),
  ADD KEY `StudentID` (`StudentID`),
  ADD KEY `StudentName` (`StudentName`,`DOB`,`Gender`,`CountryOfBirth`,`StateOfBirth`,`CityOfBirth`,`Address`,`City`,`State`,`ZipCode`,`Status`,`UpdatedOn`,`UpdatedBy`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`SubjectID`),
  ADD KEY `SubjectID` (`SubjectID`),
  ADD KEY `SubjectName` (`SubjectName`,`ClassName`,`Duration`,`Status`,`UpdatedOn`),
  ADD KEY `ClassName` (`ClassName`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `classes`
--
ALTER TABLE `classes`
  ADD CONSTRAINT `classes_ibfk_1` FOREIGN KEY (`Subject`) REFERENCES `subjects` (`SubjectID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `classes_ibfk_2` FOREIGN KEY (`Teacher`) REFERENCES `employees` (`EmpID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `exams`
--
ALTER TABLE `exams`
  ADD CONSTRAINT `exams_ibfk_1` FOREIGN KEY (`StudentID`) REFERENCES `students` (`StudentID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `exams_ibfk_2` FOREIGN KEY (`SubjectName`) REFERENCES `subjects` (`SubjectID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `exams_ibfk_3` FOREIGN KEY (`EmpName`) REFERENCES `employees` (`EmpID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `subjects_ibfk_1` FOREIGN KEY (`ClassName`) REFERENCES `classes` (`ClassID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
