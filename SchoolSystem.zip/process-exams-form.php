<?php
if(isset($_POST['AddRecord']))
{
$ExamID = $_POST["ExamID"];
$ClassName = $_POST["ClassName"];
$SubjectName = $_POST["SubjectName"];
$Section = $_POST["Section"];
$EmpName = $_POST["EmpName"];
$StudentID = $_POST["StudentID"];
$StudentName = $_POST["StudentName"]
$DateOfExam = $_POST["DateOfExam"];
$Duration = $_POST["Duration"];
$Grade = $_POST["Grade"];
$UpdatedOn = $_POST["UpdatedOn"];
}

$host = "localhost";
$username = "root";
$password = "";
$dbname = "schoolsystem"

$conn = mysqli_connect(hostname: $host,
                username: $username,
                password: $password, 
                database: $dbname);

if (!$conn) {
    die("Connection error: " . mysqli_connect_error());
}

echo "Connection successful.";

$sql = "INSERT INTO exams (ExamID, ClassName, SubjectName, Section, EmpName, StudentID, StudentName, DateOfExam, Duration, Grade, UpdatedOn)
    VALUES('0', '$ClassName', '$SubjectName', '$Section', '$EmpName', '0', '$StudentName',
    '$DateOfExam', '$Duration', '$Grade', '$UpdatedOn')";

qli_query($conn, $sql);

Record Saved.

ose($conn);
?>