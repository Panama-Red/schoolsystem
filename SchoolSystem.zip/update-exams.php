//exams

<?php
include('process-exams-form.php');

if(isset($_GET['Edit']))
{
$id = $_GET['Edit'];
$query = "SELECT ExamID, ClassName, SubjectName, Section, EmpName, StudentID, StudentName, DateOfExam, Duration, Status, UpdatedOn
FROM exams
WHERE id= $id;
$result = mysqli_query($conn, $query);
$editData = mysqli_fetch_assoc($result);

$ExamID = $editData['ExamID'];
$ClassName = $editData['ClassName'];
$SubjectName = $editData['SubjectName'];
$Section = $editData['Section'];
$EmpName = $editData['EmpName'];
$StudentID = $editData['StudentID'];
$StudentName = $editData['StudentName'];
$DateOfExam = $editData['DateOfExam'];
$Duration = $editData['Duration'];
$Status = $editData['Status'];
$UpdatedOn = $editData['UpdatedOn'];
}

?>